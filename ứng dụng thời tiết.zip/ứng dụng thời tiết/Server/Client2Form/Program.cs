﻿using System;
using System.Windows.Forms;

public partial class Client2Form : Form
{
    private readonly WeatherClient2 client2;

    public Client2Form()
    {
        InitializeComponent();
        client2 = new WeatherClient2(this);
    }

    private async void Client2Form_Load(object sender, EventArgs e)
    {
        await client2.ReceiveWeatherData();
    }

    public void UpdateWeatherData(string weatherData)
    {
        if (InvokeRequired)
        {
            Invoke(new Action<string>(UpdateWeatherData), weatherData);
            return;
        }
        weatherLabel.Text = $"Weather Data: {weatherData}";
    }
}
