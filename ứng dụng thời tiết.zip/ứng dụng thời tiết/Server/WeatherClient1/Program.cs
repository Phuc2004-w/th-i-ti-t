﻿using System;
using System.Net.Http;
using System.Net.WebSockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

public class WeatherClient1
{
    private static readonly HttpClient httpClient = new HttpClient();

    public async Task SendWeatherData(string apiKey, string city)
    {
        // Lấy dữ liệu thời tiết từ API
        var response = await httpClient.GetStringAsync($"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={apiKey}");

        using (var client = new ClientWebSocket())
        {
            client.Options.SetRequestHeader("Client-ID", "client1");
            await client.ConnectAsync(new Uri("ws://localhost:8080/"), CancellationToken.None);

            var weatherData = Encoding.UTF8.GetBytes(response);
            await client.SendAsync(new ArraySegment<byte>(weatherData), WebSocketMessageType.Text, true, CancellationToken.None);

            Console.WriteLine("Đã gửi dữ liệu thời tiết đến server");
        }
    }
}
