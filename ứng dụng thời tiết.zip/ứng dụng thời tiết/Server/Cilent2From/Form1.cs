﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using Newtonsoft.Json.Linq;

namespace Cilent2From
{
    public partial class Form1 : Form
    {
        private static readonly HttpClient httpClient = new HttpClient();
        private object conditionLabel;
        private object temperatureLabel;

        public object JObject { get; private set; }

        public Form1()
        {
            InitializeComponent();
        }

        private async void UpdateWeatherButton_Click(object sender, EventArgs e)
        {
            await GetWeatherData("Ho Chi Minh City", "d06dd7f907d8e44bb87de7af026b34ee");
        }

        private async Task GetWeatherData(string city, string apiKey)
        {
            string url = $"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={apiKey}&units=metric";
            var response = await httpClient.GetStringAsync(url);
            var weatherData = JObject(response);

            // Hiển thị dữ liệu thời tiết lên form
            temperatureLabel = $"{weatherData["main"]["temp"]}°C";
            conditionLabel = weatherData["weather"][0]["description"].ToString();
        }
    }
}
