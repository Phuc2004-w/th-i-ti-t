﻿using System;
using System.Net.WebSockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

public class WeatherClient2
{
    private readonly Client2Form form;

    public WeatherClient2(Client2Form form)
    {
        this.form = form;
    }

    public async Task ReceiveWeatherData()
    {
        using (var client = new ClientWebSocket())
        {
            client.Options.SetRequestHeader("Client-ID", "client2");
            await client.ConnectAsync(new Uri("ws://localhost:8080/"), CancellationToken.None);

            var buffer = new byte[1024];
            while (client.State == WebSocketState.Open)
            {
                var result = await client.ReceiveAsync(new ArraySegment<byte>(buffer), CancellationToken.None);
                if (result.MessageType == WebSocketMessageType.Text)
                {
                    var weatherData = Encoding.UTF8.GetString(buffer, 0, result.Count);
                    form.UpdateWeatherData(weatherData);
                }
            }
        }
    }
}

public class Client2Form
{
    internal void UpdateWeatherData(string weatherData)
    {
        throw new NotImplementedException();
    }
}